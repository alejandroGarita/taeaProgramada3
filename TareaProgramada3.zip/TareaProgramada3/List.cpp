/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   List.cpp
 * Author: Gollo
 * 
 * Created on 8 de mayo de 2017, 08:54 PM
 */

#include "List.h"
#include "Persona.h"
#include <malloc.h>
#include <iostream>
#include <cstring>

List::List() {
    headNode=NULL;
}

List::List(const List& orig) {
}

List::~List() {
}

void List::insertarNodo(string nombre, string cedula, char genero, int edad, int salario){
    
    NODEPTR newPtr, tempPtr;
    
    newPtr=new NODE;
    newPtr->persona.setNombre(nombre);
    newPtr->persona.setCedula(cedula);
    newPtr->persona.setGenero(genero);
    newPtr->persona.setEdad(edad);
    newPtr->persona.setSalario(salario);

    newPtr->nextPtr=NULL;
    
    //guardar el head
    tempPtr=headNode;
    //asignar nuevo head
    headNode=newPtr;
    //pegar el nuevo head con el valor anterior
    newPtr->nextPtr=tempPtr;
    
    
}//insertarNodo

void List::buscarNombre(string nombre){
    NODEPTR tempPtr=headNode;
    List listNombre;
    
    while(tempPtr!=NULL){
        if(tempPtr->persona.getNombre().compare(nombre)==0){
           listNombre.insertarNodo(tempPtr->persona.getNombre(),tempPtr->persona.getCedula(),tempPtr->persona.getGenero(),tempPtr->persona.getEdad(),tempPtr->persona.getSalario());
           tempPtr=tempPtr->nextPtr;
        }
        else{
            tempPtr=tempPtr->nextPtr;
        }
    }
    listNombre.printList();
    
}//buscarNombre

void List::buscarGenero(char genero){
    NODEPTR tempPtr=headNode;
    List listGenero;
    
    while(tempPtr!=NULL){
        if(tempPtr->persona.getGenero()==genero){
            listGenero.insertarNodo(tempPtr->persona.getNombre(),tempPtr->persona.getCedula(),tempPtr->persona.getGenero(),tempPtr->persona.getEdad(),tempPtr->persona.getSalario());
            tempPtr=tempPtr->nextPtr;
        }else    tempPtr=tempPtr->nextPtr;
    }
    
    listGenero.printList();
    
}//buscarGenero

int List::buscarCedula(string cedula){
    NODEPTR tempPtr=headNode;
    
    while(tempPtr!=NULL){
        if(tempPtr->persona.getCedula().compare(cedula)==0){
            cout<<"Nombre: "<<tempPtr->persona.getNombre()<<" Cedula: "<<tempPtr->persona.getCedula()<<" Genero: "<<tempPtr->persona.getGenero()<<" Edad: "<<tempPtr->persona.getEdad()<<" Salario: "<<tempPtr->persona.getSalario()<<endl;
            return 0;
        }
        else{
            tempPtr=tempPtr->nextPtr;
        }
    }
    cout<<"Cedula No encontrado\n";
    return -1;
    
}//buscarCedula

int List::eliminarNodo(string cedula){
    NODEPTR  tempPtr, previousPtr;
    
    tempPtr=headNode;
    previousPtr=NULL;
    
    if(tempPtr==NULL){
        return -1;
    }else{
    
        if(tempPtr->persona.getCedula().compare(cedula)==0){
            headNode=tempPtr->nextPtr;
            return 0;
        }else{
            while(tempPtr!=NULL){
                previousPtr=tempPtr;
                tempPtr=tempPtr->nextPtr;
                if(tempPtr!=NULL){
                    if(tempPtr->persona.getCedula().compare(cedula)==0){
                        previousPtr->nextPtr=tempPtr->nextPtr;
                        return 0;
                    }
                }
            }
            if(tempPtr==NULL){
                return -1;
            }
        }
        return -1;
    }
}//eliminarNodo

int List::actualizarNodo(string cedula,int edad, int salario){
    NODEPTR  tempPtr, previousPtr;
    
    tempPtr=headNode;
    previousPtr=NULL;
    
    if(tempPtr==NULL){
        return -1;
    }else{
    
        if(tempPtr->persona.getCedula().compare(cedula)==0){
            tempPtr->persona.setEdad(edad);
            tempPtr->persona.setSalario(salario);
            cout<<"Nodo actualizado\n";
            return 0;
        }else{
            while(tempPtr!=NULL){
                previousPtr=tempPtr;
                tempPtr=tempPtr->nextPtr;
                if(tempPtr!=NULL){
                    if(tempPtr->persona.getCedula().compare(cedula)==0){
                        tempPtr->persona.setEdad(edad);
                        tempPtr->persona.setSalario(salario);
                        cout<<"Nodo actualizado\n";
                        return 0;
                    }
                }
            }
            if(tempPtr==NULL){
                return -1;
            }
        }
        return -1;
    }
}


void List::printList(){
    
    NODEPTR tempNode=headNode;
    
    if(tempNode!=NULL){
        while(tempNode!=NULL){
            cout<<"Nombre: "<<tempNode->persona.getNombre()<<" Cedula: "<<tempNode->persona.getCedula()<<" Genero: "<<tempNode->persona.getGenero()<<" Edad: "<<tempNode->persona.getEdad()<<" Salario: "<<tempNode->persona.getSalario()<<endl;
            tempNode=tempNode->nextPtr;
        }
        cout<<"NULL\n\n";
    }else{
        cout<<"The list is empty.\n\n";
    }
}
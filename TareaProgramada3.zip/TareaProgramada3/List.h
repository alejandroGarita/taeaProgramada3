/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   List.h
 * Author: Gollo
 *
 * Created on 8 de mayo de 2017, 08:54 PM
 */

#ifndef LIST_H
#define LIST_H

#include "string"
#include "Persona.h"

using namespace std;

class List {
public:
    List();
    List(const List& orig);
    virtual ~List();
    
    void insertarNodo(string nombre,string cedula, char genero, int edad, int salario);
    void buscarNombre(string nombre);
    int buscarCedula(string cedula);
    void buscarGenero(char genero);
    int eliminarNodo(string cedula);
    int actualizarNodo(string cedula,int edad, int salario);
    void printList();
    
private:
 struct node{
        Persona persona;
        struct node *nextPtr;
    };
    
    typedef struct node NODE;
    typedef NODE *NODEPTR;

    NODEPTR headNode;
};

#endif /* LIST_H */


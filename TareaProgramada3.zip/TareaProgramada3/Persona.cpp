/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Persona.cpp
 * Author: Gollo
 * 
 * Created on 10 de mayo de 2017, 10:32 AM
 */

#include "Persona.h"

Persona::Persona() {
}

Persona::Persona(const Persona& orig) {
}

Persona::~Persona() {
}

void Persona::setNombre(string nombre){
    this->nombre=nombre;
}

string Persona::getNombre() const{
    return this->nombre;
}

void Persona::setCedula(string cedula){
    this->cedula=cedula;
}

string Persona::getCedula() const{
    return this->cedula;
}

void Persona::setGenero(char genero){
    this->genero=genero;
}

char Persona::getGenero() const{
    return this->genero;
}

void Persona::setEdad(int edad){
    this->edad=edad;
}

int Persona::getEdad() const{
    return this->edad;
}

void Persona::setSalario(int salario){
    this->salario=salario;
}

int Persona::getSalario() const{
    return this->salario;
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Persona.h
 * Author: Gollo
 *
 * Created on 10 de mayo de 2017, 10:32 AM
 */

#ifndef PERSONA_H
#define PERSONA_H

#include <iostream>
#include "string"

using namespace std;

class Persona {
public:
    Persona();
    Persona(const Persona& orig);
    virtual ~Persona();
    void setNombre(string nombre);
    string getNombre() const;
    void setCedula(string cedula);
    string getCedula() const;
    void setGenero(char genero);
    char getGenero() const;
    void setEdad(int edad);
    int getEdad() const;
    void setSalario(int salario);
    int getSalario() const;
    
private:
    string nombre;
    string cedula;
    char genero;
    int edad;
    int salario;
};

#endif /* PERSONA_H */


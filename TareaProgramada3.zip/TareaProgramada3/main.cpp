/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Gollo
 *
 * Created on 8 de mayo de 2017, 08:50 PM
 */

#include <cstdlib>
#include <iostream>
#include "List.h"
#include "Persona.h"
#include <fstream>

using namespace std;

/*
 * 
 */

void menu(){
    List myList;
    int opcion=0;
    
    while(opcion!=6){ 
        cout<<"\nQue accion desea realizar:\n1-->Insertar Persona\n2-->Eliminar Persona\n3-->Buscar Persona\n4-->Actualizar Persona\n5-->Imprimir Lista\n6-->Salir"<<endl;
        cin>>opcion;
        switch(opcion){
            case 1:{
                cout<<"Ingrese el nombre\n";
                string nombre;
                cin>>nombre;
                cout<<"Ingrese la cedula\n";
                string cedula;
                cin>>cedula;
                cout<<"Ingrese el genero\n1-->Hombre\n2-->Mujer\n";
                int sexo;
                cin>>sexo;
                char genero;
                if(sexo==1)
                    genero='H';
                else genero='M';
                cout<<"Ingrese la edad\n";
                int edad;
                cin>>edad;
                cout<<"Ingrese el salario\n";
                int salario;
                cin>>salario;
                myList.insertarNodo(nombre,cedula,genero,edad,salario);
            }
            break;
            case 2:{
                cout<<"Ingrese la cedula\n";
                string cedula;
                cin>>cedula;
                myList.eliminarNodo(cedula);
            }
            break;
            case 3:{
                int busqueda;
                cout<<"Busqueda por:\n1-->Nombre\n2-->Cedula\n3-->Genero\n";
                cin>>busqueda;
                if(busqueda==1){
                    cout<<"Ingrese el nombre\n";
                    string nombre;
                    cin>>nombre;
                    myList.buscarNombre(nombre);
                }else if(busqueda==2){
                        cout<<"Ingrese la cedula\n";
                        string cedula;
                        cin>>cedula;
                        myList.buscarCedula(cedula);
                    }else {
                        cout<<"Genero a buscar\n1-->Hombre\n2-->Mujer\n";
                        int genero;
                        cin>>genero;
                        if(genero==1)
                            myList.buscarGenero('H');
                        else myList.buscarGenero('M');
                    }
            }
            break;
            case 4:{
                cout<<"Ingrese la cedula\n";
                string cedula;
                cin>>cedula;
                cout<<"Ingrese la edad\n";
                int edad;
                cin>>edad;
                cout<<"Ingrese el salario\n";
                int salario;
                cin>>salario;
                myList.actualizarNodo(cedula,edad,salario);
            }
            break;
            case 5:{
                myList.printList();
            }
            break;
        }//switch
    }// while
}// menu


void cargarLista(){
    ifstream file;
    
//    file.open("lista.txt");
//    cout<<"lista creada\n";
//    file<<"hola";
//    file.close();
//    cout<<"archivo cerrado\n";
    
    file.open("lista.txt");
    cout<<"archivo abierto\n";
    string frase;
    getline(file,frase);
    cout<<"Frase: "<<frase<<"\n";
    file.close();
    cout<<"archivo cerrado\n";
}//cargarLista

int main(int argc, char** argv) {

    cargarLista();
    menu();
    
    return 0;
}// main

